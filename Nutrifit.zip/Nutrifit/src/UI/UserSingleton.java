package UI;

/* Incorporates the singleton design pattern
* Contains database & profile object point of reference */


import NutrifitDatabase.IManageUserData;
import NutrifitDatabase.ManageUserDataMySQL;

/**
 * Singleton design pattern implementation. Contains database and profile object.
 * Provides a global single reference access point for the user object. Singleton is
 * utilized because no two user profiles are required at the same time in this application.
 */
public class UserSingleton {
    private static UserSingleton instance;;
    private static IManageUserData profile;
    private static boolean validProfile;

    //Constructor
    private UserSingleton(){
        profile = new ManageUserDataMySQL();
    }

    public static UserSingleton getInstance() {
        if(instance == null){
            instance = new UserSingleton();
        }
        return instance;
    }

    //Choose or update the profile. Must be initialized already.
    public static void setProfile(String username, String password){
        try{
            profile.setUser(username, password);
            validProfile = true;
        }
        catch (Exception e) {
            System.out.println("Profile information invalid!");
            validProfile = false;
        }
    }

    //Use for checking if login screen should proceed
    public static boolean getValidity(){
        return validProfile;
    }

    //Ensure profile is set beforehand
    public static IManageUserData getProfile(){
        if(validProfile){
            return profile;
        }
        return null;
    }

    //Close Profile whenever a profile switch occurs
    public static void closeProfile(){
        profile.close();
    }

}
