package UI;

import javax.swing.*;
import java.awt.*;

/**
 * Listens for observer and makes updates in Visualizer Window
 */
public class VisualizeWindowListener implements Observer{
    public VisualizeWindowListener(){
        super();
        ObserveDataChange.attach(this);
    }

    //When profile data changes, clear all JtextFields in Visualize Window
    @Override
    public void update(){

        //Container con = VisualizeWindow.getVisExercisePanel();
        for(Component control : VisualizeWindow.getVisExercisePanel().getComponents()) {
            if (control instanceof JTextField) {
                JTextField ctrl = (JTextField) control;
                ctrl.setText("");
            }
        }
        for(Component control : VisualizeWindow.getVisNutrientPanel().getComponents()) {
            if (control instanceof JTextField) {
                JTextField ctrl = (JTextField) control;
                ctrl.setText("");
            }
        }
    }


}
