package UI;

import javax.swing.*;
import java.awt.*;

/**
 * The main JTabbedPane which houses the following tabs "Profiles, Diet Logs, Exercise Logs,
 * Visualizer, Assessments"
 */
public class HubWindow {
    private HubWindow(JTabbedPane window){
        initialize(window);
    }

    //Initialize JSwing Elements (called once)
    public static void initialize(JTabbedPane window) {

        //Create Tabs on the left-side of the window
        window.setTabPlacement(JTabbedPane.LEFT);
        window.setFont(new Font("Arial", Font.PLAIN, 16));

        JTabbedPane windowProfile = ProfileWindow.initialize();
        JTabbedPane windowDiet = DietWindow.initialize();
        JTabbedPane windowExercise = ExerciseWindow.initialize();
        JTabbedPane windowVisualizer = VisualizeWindow.initialize();
        JTabbedPane windowAssessment = AssessmentsWindow.initialize();

        //Create elements
        createTabs(window, windowProfile, windowDiet, windowExercise, windowVisualizer, windowAssessment);
    }

    private static void createTabs(JTabbedPane tabbedPane, JComponent... arg) {
        tabbedPane.add("Profiles", arg[0]);
        tabbedPane.add("Diet Logs", arg[1]);
        tabbedPane.add("Exercise Logs", arg[2]);
        tabbedPane.add("Visualizer", arg[3]);
        tabbedPane.add("Assessments", arg[4]);
    }

}
