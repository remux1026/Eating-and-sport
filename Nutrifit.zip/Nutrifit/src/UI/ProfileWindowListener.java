package UI;

import NutrifitDatabase.IManageUserData;
import javax.swing.*;

/**
 * Listens for observer and makes updates in Profile Window
 */
public class ProfileWindowListener implements Observer{

    public ProfileWindowListener(){
        super();
        ObserveDataChange.attach(this);
    }

    //Updates the profile info tab
    @Override
    public void update(){
        JLabel[] label = ProfileWindow.getLabels();
        IManageUserData user = UserSingleton.getInstance().getProfile();

        label[0].setText(user.getProfileData().get("UserID"));
        label[1].setText(user.getProfileData().get("Email"));
        label[2].setText(user.getProfileData().get("Username"));
        label[3].setText(user.getProfileData().get("FirstName") + " " + user.getProfileData().get("LastName"));
        label[4].setText(user.getProfileData().get("Sex"));
        label[5].setText(user.getProfileData().get("Birthday"));
        label[6].setText(user.getProfileData().get("Height"));
        label[7].setText(user.getProfileData().get("Weight"));

        //UserSingleton.getInstance().closeProfile(); //Debug
    }
}
