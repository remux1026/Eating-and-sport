package UI;

import net.miginfocom.swing.MigLayout;

import NutrifitDatabase.FatLossPrediction;
import NutrifitDatabase.CompareCFGDiet;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;

/**
 * Contains use case 6 (Weight Loss Assessment) and use case 7 (Canada Food Guide Alignment)
 * tabs and functionality.
 */
public class AssessmentsWindow{

    private static JPanel visWeightLoss;
    private static JPanel visCFGAlignment;

    private AssessmentsWindow(){
        initialize();
    }

    public static JTabbedPane initialize() {
        new AssessmentsWindowListener();

        JTabbedPane windowVisualize = new JTabbedPane();
        visWeightLoss = new JPanel();
        visCFGAlignment = new JPanel();
        visWeightLoss.setLayout(new MigLayout("fillx, align 50% 50%"));
        visCFGAlignment.setLayout(new MigLayout("fillx, align 50% 50%"));

        createWeightAssessmentWindow();
        createCFGAlignmentWindow();
        createTabs(windowVisualize, visWeightLoss, visCFGAlignment);

        return windowVisualize;
    }

    //Create the tabs inside the Assessments window
    private static void createTabs(JTabbedPane windowVisualize, JComponent... arg) {

        windowVisualize.add("Weight Loss Assessment", arg[0]);
        windowVisualize.add("Canada Food Guide Alignment", arg[1]);
    }

    //Create layout of the Assessment Window
    private static void createWeightAssessmentWindow(){
        JLabel description = new JLabel("Given your current exercise log and my calory intake, Select a specific");
        JLabel description2 = new JLabel("date and find out how much fat you will lose by this date.");

        JLabel labelDate = new JLabel("Date (yyyy-MM-dd): ");
        JTextField textDate = new JTextField();

        JButton btnSubmit = new JButton("Submit");
        btnSubmit.addActionListener( new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {

                    double fatLost = FatLossPrediction.predict(UserSingleton.getInstance().getProfile(), textDate.getText());

                    DecimalFormat formatter = new DecimalFormat("#0.00");

                    if (fatLost > 0) {
                        JOptionPane.showMessageDialog(null,
                                "Based on recent excerise and diet you will Lose (kg): " + formatter.format(fatLost));
                    } else {
                        JOptionPane.showMessageDialog(null,
                                "Based on recent excerise and diet you will Gain (kg): " + formatter.format(fatLost * -1));
                    }

                } catch (Exception DateWrong) {
                    JOptionPane.showMessageDialog(null,
                            "Date Invalid or No Logs in Recently (2 weeks)", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        BackEndMethods.setFontSize(16, description, description2,
                labelDate);
        BackEndMethods.setFieldSize(200, 20, textDate);

        visWeightLoss.add(description, "wrap");
        visWeightLoss.add(description2, "wrap 50");
        visWeightLoss.add(labelDate);
        visWeightLoss.add(textDate, "wrap push");
        visWeightLoss.add(btnSubmit, "align center, grow x");
    }

    //Create layout of the CFG assessment Window
    private static void createCFGAlignmentWindow() {
        JLabel description = new JLabel("Visualize your current average plate in terms of percentages");
        JLabel description2 = new JLabel("of food groups represented and compare it to the Canadian  ");
        JLabel description3 = new JLabel("Food Guide recommendations.");


        JButton btnSubmit = new JButton("Visualize");
        btnSubmit.addActionListener( new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                try {
                    getCFG();
                } catch(Exception SomeError) {
                    JOptionPane.showMessageDialog(null,
                            "Some Error Occured", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        BackEndMethods.setFontSize(16, description, description2, description3, btnSubmit);
        BackEndMethods.setFieldSize(160, 80, btnSubmit);

        visCFGAlignment.add(description, "align center, wrap");
        visCFGAlignment.add(description2, "align center, wrap");
        visCFGAlignment.add(description3, "align center, wrap 50");
        visCFGAlignment.add(btnSubmit, "align center, growy");
    }

    private static void getCFG() throws Exception {
        CompareCFGDiet.compareCFGVisual(UserSingleton.getInstance().getProfile());
    }

    public static JPanel getVisWeightLossPanel(){
        return visWeightLoss;
    }
}
