package UI;

import NutrifitDatabase.IManageUserData;
import net.miginfocom.swing.MigLayout;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.URISyntaxException;
import java.util.ArrayList;

/**
 * The first window displayed upon launching the application. Reads from username.txt file
 * in /src/resources/ to load profiles into the screen. Has add profile functionality, which
 * will create a profile in the database and write into username.txt
 */
public class SplashScreen{

    private SplashScreen(JFrame frame){
        initialize(frame);
    }

    private static JPanel mainPanel;
    private static CardLayout card;
    private static JPanel profilePanel;

    //Initialize JSwing Elements (called once)
    public static void initialize(JFrame frame) {

        //Initialize main windows/cards
        mainPanel = new JPanel();
        JPanel splashScreen = new JPanel();
        profilePanel = new JPanel();
        JPanel createProfileWindow = new JPanel();
        JTabbedPane hubWindow = new JTabbedPane();
        JPanel loginWindow = new JPanel();
        card = new CardLayout();
        mainPanel.setLayout(card);
        mainPanel.add(splashScreen, "splashScreen"); //id to refer to splashScreen when switching
        mainPanel.add(createProfileWindow, "createProfileWindow");
        mainPanel.add(hubWindow, "hubWindow");
        mainPanel.add(loginWindow, "loginWindow");
        frame.add(mainPanel);

        //Initialize other windows
        SplashCreateProfile.initialize(createProfileWindow);
        SplashLoginWindow.initialize(loginWindow, card, mainPanel);
        HubWindow.initialize(hubWindow);

        //Initialize splashScreen window
        profilePanel.setLayout(new MigLayout("align 50% 50%"));
        splashScreen.setLayout(new MigLayout("align 50% 50%"));
        JLabel message = new JLabel("Choose your profile:");
        JLabel extraGap = new JLabel();
        BackEndMethods.setFontSize(20, message);

        //Display all available profiles & add profile button
        int numProfiles = readUsernameFile().size();
        splashScreen.add(message, "align center, dock north");
        splashScreen.add(extraGap, "gaptop 20");
        splashScreen.add(profilePanel);
        setProfilePanel(numProfiles);
    }

    //Attaches profile portion into splashscreen
    public static void setProfilePanel(int numProfiles){
        JButton btnCreateProfile = new JButton("+");
        JLabel labelCreateProfile = new JLabel("Add Profile");
        btnCreateProfile.setPreferredSize(new Dimension(80, 80));

        setExistingProfiles(profilePanel, card, mainPanel);
        profilePanel.add(btnCreateProfile, "align center, cell " +numProfiles+1 + " 1");
        profilePanel.add(labelCreateProfile, "align center, cell " +numProfiles+1 + " 2");

        //Create profile button pressed leads to profile creation window
        btnCreateProfile.addActionListener( new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                showScreen("createProfileWindow");
            }
        });
    }

    //Load profiles into profilePanel portion in splashscreen.
    private static void setExistingProfiles(JPanel splashScreen, CardLayout card, JPanel mainPanel){

        ArrayList<String> usernameData = readUsernameFile();
        int length = usernameData.size();

        //Create icon & username label for each user in the text file
        for(int i=0; i<length;i++){

            JButton btnProfile = new JButton();
            JLabel username = new JLabel(usernameData.get(i));
            btnProfile.setPreferredSize(new Dimension(80, 80));
            btnProfile.setMargin(new Insets(0, 0, 0, 0));

            //Button functionality - press for login screen
            int finalI = i;
            btnProfile.addActionListener(new ActionListener()
            {
                @Override
                public void actionPerformed(ActionEvent e)
                {
                    showScreen("loginWindow");
                    SplashLoginWindow.setUsername(usernameData.get(finalI), SplashLoginWindow.getUsername());
                }
            });

            try {
                Image img = ImageIO.read(SplashScreen.class.getResource("/resources/ava_blue.png"));
                Image newImg = img.getScaledInstance(80, 80,  java.awt.Image.SCALE_SMOOTH ) ;
                btnProfile.setIcon(new ImageIcon(newImg));
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null,
                        "There was an error with loading this profile!", "Error", JOptionPane.ERROR_MESSAGE);
            }

            splashScreen.add(btnProfile, "align center, cell " +i+1 + " 1");
            splashScreen.add(username, "align center, cell " +i+1 + " 2");
        }
    }

    //Read the username.txt file in 'resources' folder. Used to load profiles into splashscreen.
    private static ArrayList<String> readUsernameFile() {

        //ArrayList to store all usernames found
        ArrayList<String> lines = new ArrayList();

        //Read all usernames from the username.txt file
        try {
            FileReader f = new FileReader(new File(SplashScreen.class.getResource(
                    "/resources/usernames.txt").toURI()));
            BufferedReader reader = new BufferedReader(f);

            String line;
            while ((line = reader.readLine()) != null) {
                // Skip blank lines
                if (line.trim().length() == 0) {
                    continue;
                }
                lines.add(line);
            }

        } catch (IOException e) {
            e.printStackTrace();
        } catch (URISyntaxException e) {
            throw new RuntimeException(e);
        }

        return lines;
    }

    //Method for loading a different screen
    public static void showScreen(String name){
        card.show(mainPanel, name);
    }

    public static JPanel getProfilePanel(){
        return profilePanel;
    }

    public static int getNumUsernames(){
        return readUsernameFile().size();
    }

}
