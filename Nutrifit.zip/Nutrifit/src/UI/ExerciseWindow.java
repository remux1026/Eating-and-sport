package UI;

import net.miginfocom.swing.MigLayout;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Contains use case 3 functionality: exercise logging. User's logs from the database will be displayed in the
 * Exercise Entries tab. Ability to create an entry into the database through the "create entry" tab,
 * which will notify observers & update profile data accordingly.
 */
public class ExerciseWindow {

    private static JPanel tabEntries;

    public static JTabbedPane initialize() {
        new ExerciseWindowListener();

        JTabbedPane windowExercise = new JTabbedPane();
        tabEntries = new JPanel();
        tabEntries.setLayout(new MigLayout("fill"));
        JPanel tabCreate = new JPanel();
        createNewEntryLayout(tabCreate);

        createLayout(windowExercise, tabEntries, tabCreate);

        return windowExercise;
    }

    private static void createLayout(JTabbedPane tabProfile, JComponent... arg) {

        tabProfile.add("Exercise Entries", arg[0]);
        tabProfile.add("Create Entry", arg[1]);
    }

    private static void createNewEntryLayout(JPanel tabCreate){
        tabCreate.setLayout(new MigLayout("fill, align 50% 50%"));
        String[] choiceType = {"Walking", "Running", "Biking", "Swimming", "Others"};
        String[] choiceIntensity = {"Low", "Medium", "High", "Very High"};

        JLabel message = new JLabel("------------ Input Entry Information ------------");
        JButton btnSubmit = new JButton("Submit");
        JButton btnReset = new JButton("Reset");

        JLabel labelDate = new JLabel("Date (YYYY-MM-DD):");
        JLabel labelDuration = new JLabel("Duration (H.m):");
        JLabel labelType = new JLabel("Type:");
        JLabel labelIntensity = new JLabel("Intensity:");

        JTextField textDate = new JTextField();
        JTextField textDuration = new JTextField();
        JComboBox textType = new JComboBox(choiceType);
        JComboBox textIntensity = new JComboBox(choiceIntensity);

        BackEndMethods.setFontSize(16, labelDate, labelType,
                labelDuration, labelIntensity);
        BackEndMethods.setFieldSize(200, 20, textDate, textDuration,
                textType, textIntensity);

        //Submit button pressed:
        btnSubmit.addActionListener( new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                try {
                    Double duration = Double.parseDouble(textDuration.getText());
                    String type = textType.getSelectedItem().toString();
                    String intensity = getIntensityChoice(textIntensity);
                    String date = textDate.getText();

                    UserSingleton.getInstance().getProfile()
                            .insertUserExercise(intensity, type, duration, date);

                    //Refresh the entries and update the data
                    BackEndMethods.refreshEntries(ExerciseWindow.getEntriesPanel(), DietWindow.getEntriesPanel());
                    ObserveDataChange.notifyObservers();

                    JOptionPane.showMessageDialog(null, "New entry added!");
                    resetFields(textDate, textDuration, textType, textIntensity);

                }catch(Exception ex){
                    JOptionPane.showMessageDialog(null,
                            "Inputs are incorrect format!", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        //Reset button pressed:
        btnReset.addActionListener( new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                int confirm = JOptionPane.showOptionDialog(
                        null, "Reset fields?",
                        "Confirmation", JOptionPane.YES_NO_OPTION,
                        JOptionPane.QUESTION_MESSAGE, null, null, null);
                if (confirm == 0) {
                    resetFields(textDate, textDuration, textType, textIntensity);
                }
            }
        });

        tabCreate.add(labelDate, "gaptop 30");
        tabCreate.add(textDate, "wrap");
        tabCreate.add(labelDuration);
        tabCreate.add(textDuration, "wrap");
        tabCreate.add(labelType);
        tabCreate.add(textType, "wrap");
        tabCreate.add(labelIntensity);
        tabCreate.add(textIntensity, "wrap push");

        tabCreate.add(message, "grow, dock north");
        tabCreate.add(btnReset, "grow");
        tabCreate.add(btnSubmit, "grow");
    }

    private static String getIntensityChoice(JComboBox textIntensity){
        int choice = textIntensity.getSelectedIndex();
        return switch (choice) {
            default -> "L";
            case 1 -> "M";
            case 2 -> "H";
            case 3 -> "V";
        };
    }

    private static void resetFields(JTextField textDate, JTextField textDuration,
                                    JComboBox textType, JComboBox textIntensity){
        textDate.setText("");
        textDuration.setText("");
        textType.setSelectedIndex(0);
        textIntensity.setSelectedIndex(0);
    }

    public static JPanel getEntriesPanel(){
        return tabEntries;
    }

}
