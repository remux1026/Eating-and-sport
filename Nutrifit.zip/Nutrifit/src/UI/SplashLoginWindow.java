package UI;

import net.miginfocom.swing.MigLayout;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Accessed after clicking on a profile in SplashScreen. Requires correct username and password
 * (compared to the database) to access HubWindow
 */
public class SplashLoginWindow {

    private static JTextField textUsername;
    private static JPasswordField textPassword;

    private SplashLoginWindow(JPanel window, CardLayout card, JPanel mainPanel){
        initialize(window, card, mainPanel);
    }

    //Initialize JSwing Elements (called once)
    public static void initialize(JPanel window, CardLayout card, JPanel mainPanel) {

        window.setLayout(new MigLayout("align 50% 50%"));

        JLabel message = new JLabel("------------ Log in ------------");
        JButton btnSubmit = new JButton("Submit");
        JButton btnBack = new JButton("Back");

        JLabel labelUsername = new JLabel("Username:");
        JLabel labelPassword = new JLabel("Password:");
        textUsername = new JTextField();
        textPassword = new JPasswordField();

        BackEndMethods.setFontSize(20, message);
        BackEndMethods.setFontSize(16, labelUsername, labelPassword);
        BackEndMethods.setFieldSize(200, 20, textUsername, textPassword);

        window.add(labelUsername, "gaptop 50");
        window.add(textUsername, "wrap");
        window.add(labelPassword, "gaptop 10");
        window.add(textPassword, "wrap");

        window.add(message, "align center, dock north, gapbefore 20");
        window.add(btnBack, "align center, gaptop 20");
        window.add(btnSubmit, "align center");

        //Submit button pressed. Notify observers of profile change:
        btnSubmit.addActionListener( new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                try {
                    UserSingleton.getInstance().setProfile(textUsername.getText(), textPassword.getText());

                    if (UserSingleton.getInstance().getValidity()) {
                        ObserveDataChange.notifyObservers();
                        SplashScreen.showScreen("hubWindow");
                    }
                } catch(Exception ex) {
                    JOptionPane.showMessageDialog(null,
                            "Incorrect username or password!", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        //Back button pressed:
        btnBack.addActionListener( new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                SplashScreen.showScreen("splashScreen");
            }
        });
    }

    //Reset login information every time a profile button is pressed from splash screen.
    public static void setUsername(String s, JTextField textUsername){
        textPassword.setText("");
        textUsername.setText(s);
    }

    public static JTextField getUsername(){
        return textUsername;
    }

}
