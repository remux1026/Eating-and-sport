package UI;

import NutrifitDatabase.CreateNewUserMySQL;
import NutrifitDatabase.ICreateNewUser;
import net.miginfocom.swing.MigLayout;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.URISyntaxException;

/**
 * Window accessed from SplashScreen. Will create a profile in the database and write into username.txt.
 */
public class SplashCreateProfile {

    private SplashCreateProfile(JPanel window){
        initialize(window);
    }

    //Initialize JSwing Elements (called once)
    public static void initialize(JPanel window) {

        //Use MigLayout with centered elements
        window.setLayout(new MigLayout("fillx, filly, align 50% 50%"));

        JLabel message = new JLabel("------------ Input Profile Information ------------");
        JButton btnSubmit = new JButton("Submit");
        JButton btnBack = new JButton("Back");

        JLabel labelUsername = new JLabel("Username:");
        JLabel labelPassword = new JLabel("Password:");
        JLabel labelEmail = new JLabel("Email:");
        JLabel labelFirstName = new JLabel("First Name:");
        JLabel labelLastName = new JLabel("Last Name:");
        JLabel labelSex = new JLabel("Sex (M or F):");
        JLabel labelBirthdate = new JLabel("Birthdate (YYYY-MM-DD):");
        JLabel labelHeight = new JLabel("Height:");
        JLabel labelWeight = new JLabel("Weight:");

        JTextField textUsername = new JTextField();
        JTextField textPassword = new JTextField();
        JTextField textEmail = new JTextField();
        JTextField textFirstName = new JTextField();
        JTextField textLastName = new JTextField();
        JTextField textSex = new JTextField();
        JTextField textBirthdate = new JTextField();
        JTextField textHeight = new JTextField();
        JTextField textWeight = new JTextField();

        BackEndMethods.setFontSize(16, labelUsername, labelPassword,
                labelEmail, labelFirstName, labelLastName, labelSex,
                labelBirthdate,labelHeight, labelWeight);

        BackEndMethods.setFieldSize(200, 20, textUsername, textPassword,
                textEmail, textFirstName, textLastName, textSex,
                textBirthdate,textHeight, textWeight);

        window.add(labelUsername, "gaptop 30");
        window.add(textUsername, "wrap");
        window.add(labelPassword);
        window.add(textPassword, "wrap");
        window.add(labelEmail);
        window.add(textEmail, "wrap");
        window.add(labelFirstName);
        window.add(textFirstName, "wrap");
        window.add(labelLastName);
        window.add(textLastName, "wrap");
        window.add(labelSex);
        window.add(textSex, "wrap");
        window.add(labelBirthdate);
        window.add(textBirthdate, "wrap");
        window.add(labelHeight);
        window.add(textHeight, "wrap");
        window.add(labelWeight);
        window.add(textWeight, "wrap");

        window.add(message, "gapbefore 30, dock north");
        window.add(btnBack, "gaptop 30, align center");
        window.add(btnSubmit, "align center");

        //Submit button pressed:
        btnSubmit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                boolean valid = false;

                ICreateNewUser newUser = new CreateNewUserMySQL();
                try {
                    newUser.createUser(textUsername.getText(), textEmail.getText(), textPassword.getText(),
                            textSex.getText(), textBirthdate.getText(), textFirstName.getText(), textLastName.getText(),
                            Double.parseDouble(textHeight.getText()), Double.parseDouble(textWeight.getText()));

                    valid = true;

                } catch (Exception ProgiveFailed) {
                    // Add jframe error msg
                    JOptionPane.showMessageDialog(null,
                            "Inputs are incorrect format!", "Error", JOptionPane.ERROR_MESSAGE);
                }

                if (valid) {

                    FileWriter fw = null;
                    BufferedWriter bw = null;
                    PrintWriter pw = null;
                    try {
                        String str = textUsername.getText();
                        File newTextFile = new File(
                                SplashCreateProfile.class.getResource("/resources/usernames.txt").toURI());

                        fw = new FileWriter(newTextFile, true);
                        bw = new BufferedWriter(fw);
                        pw = new PrintWriter(bw);

                        pw.println(str);

                        pw.flush();

                        fw.close();
                        //Update the splash screen upon successful profile creation
                        updateSplashScreen();

                    } catch (IOException iox) {
                        // do stuff with exception
                        iox.printStackTrace();
                    } catch (URISyntaxException f) {
                        throw new RuntimeException(f);
                    }
                }
                resetFields(textUsername, textPassword,
                        textEmail, textFirstName, textLastName, textSex,
                        textBirthdate,textHeight, textWeight);
                SplashScreen.showScreen("splashScreen");
            }
        });
        //Back button pressed:
        btnBack.addActionListener( new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                SplashScreen.showScreen("splashScreen");
            }
        });
    }

    private static void resetFields(JTextField... arg){
        for(int i = 0; i < arg.length; i++) {
            arg[i].setText("");
        }
    }

    public static void updateSplashScreen(){
        SplashScreen.getProfilePanel().removeAll();
        SplashScreen.getProfilePanel().revalidate();
        SplashScreen.getProfilePanel().repaint();

        SplashScreen.setProfilePanel(SplashScreen.getNumUsernames());
    }


}
