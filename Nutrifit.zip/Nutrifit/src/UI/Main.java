package UI;

import NutrifitDatabase.DatabaseUtilities;

/**
 * The main method to run the application
 * @author Dustin Chan & Eduard Sinha
 */
public class Main {

    public static void main(String[] args) {
        new MainJFrame();

        //Debug tool to unlock profiles in the database
        //DatabaseUtilities.free(36);
    }
}
