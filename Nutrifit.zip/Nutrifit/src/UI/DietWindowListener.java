package UI;

import NutrifitDatabase.CalculationsUtilities;
import NutrifitDatabase.IManageUserData;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.List;

/**
 * Listens for observer and makes updates in Diet Window
 */
public class DietWindowListener implements Observer{
    public DietWindowListener(){
        super();
        ObserveDataChange.attach(this);
    }

    //Updates the entries tab
    @Override
    public void update(){
        JPanel panel = DietWindow.getEntriesPanel();
        IManageUserData user = UserSingleton.getInstance().getProfile();
        int dataLength = user.getUserMeals().size();

        //For each diet log in database, create an associated JButton on the entries window
        for(int i = 0; i < dataLength; i++){
            panel.add(createEntry(i), "dock north");
        }
    }

    private JButton createEntry(int i){
        IManageUserData user = UserSingleton.getInstance().getProfile();
        JButton entry = new JButton();
        JButton delete = createDeleteBtn(i);

        //Nutrient breakdown
        String mealID = user.getUserMeals().get(i).get("MealID");
        List<Map<String, String>> ingredientList = user.getUserMealIngredients();
        List<Map<String, String>> nutrients = ingredientList.stream().
                filter(v->v.get("MealID").equals(mealID)).collect(Collectors.toList());
        Map<String, Double> nutrientsBreakdown =  CalculationsUtilities.nutritionBreakdown(nutrients);


        //Click on entry button to view breakdown of nutrients
        String breakdown = "Full Nutrient Breakdown: "
                + "\n———————————"
                + "\n[Protein]: " + nutrientsBreakdown.get("Protein")
                + "\n[Calories]: " + nutrientsBreakdown.get("Calories")
                + "\n[Carbs]: " + nutrientsBreakdown.get("Carbs")
                + "\n[VitaminB6]: " + nutrientsBreakdown.get("VitaminB6")
                + "\n[VitaminB12]: " + nutrientsBreakdown.get("VitaminB12")
                + "\n[VitaminC]: " + nutrientsBreakdown.get("VitaminC")
                + "\n[Other]: " + nutrientsBreakdown.get("Other");
        entry.addActionListener( new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                JOptionPane.showMessageDialog(
                       null, breakdown);
            }
        });

        int intCalories = nutrientsBreakdown.get("Calories").intValue();

        //Set entry text
        String id = "[Meal ID:" + user.getUserMeals().get(i).get("MealID");
        String date = "     Date: " + user.getUserMeals().get(i).get("Date") + "]";
        String name = "  —  " + user.getUserMeals().get(i).get("MealName");
        String type = "     Type: " + user.getUserMeals().get(i).get("Type");
        String calories = "               Calories:" + intCalories;

        entry.setText(id + date + name + type + calories);
        entry.setPreferredSize(new Dimension(100,100));
        entry.add(delete);

        return entry;
    }

    //Creates delete button on the entry button
    private JButton createDeleteBtn(int i){
        IManageUserData user = UserSingleton.getInstance().getProfile();
        JButton delete = new JButton("X");
        delete.setForeground(Color.white);
        delete.setBackground(new Color(252, 80, 68));
        delete.addActionListener( new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                int confirm = JOptionPane.showOptionDialog(
                        null, "Are you sure you wish to delete this entry?",
                        "Delete Confirmation", JOptionPane.YES_NO_OPTION,
                        JOptionPane.QUESTION_MESSAGE, null, null, null);
                if (confirm == 0) {
                    //Delete functionality here
                    user.deleteUserMeal(
                            Integer.parseInt(user.getUserMeals().get(i).get("MealID")));

                    //Refresh the entries and update the data
                    BackEndMethods.refreshEntries(ExerciseWindow.getEntriesPanel(), DietWindow.getEntriesPanel());
                    ObserveDataChange.notifyObservers();
                }
            }
        });

        return delete;
    }
}

