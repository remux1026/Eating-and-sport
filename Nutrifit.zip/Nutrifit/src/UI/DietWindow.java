package UI;

import net.miginfocom.swing.MigLayout;

import javax.swing.*;

import NutrifitDatabase.IGetNutrientData;
import NutrifitDatabase.NutrientData;
import NutrifitDatabase.NutrientDataMySQL;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Contains use case 2 functionality: meal logging. User's logs from the database will be displayed in the
 * Diet Entries tab. Ability to create an entry into the database through the "create entry" tab,
 * which will notify observers & update profile data accordingly.
 */
public class DietWindow {

	private static List<Map<String, String>> ingredients = new ArrayList<>();

	private static JPanel tabEntries;

	public static JTabbedPane initialize() {
		new DietWindowListener(); // Populates the entries tab

		JTabbedPane windowDiet = new JTabbedPane();
		tabEntries = new JPanel();
		tabEntries.setLayout(new MigLayout("fill"));
		JPanel tabCreate = new JPanel();
		createNewEntryLayout(tabCreate);

		createLayout(windowDiet, tabEntries, tabCreate);

		return windowDiet;
	}

	private static void createLayout(JTabbedPane tabProfile, JComponent... arg) {

		tabProfile.add("Diet Entries", arg[0]);
		tabProfile.add("Create Entry", arg[1]);
	}

	private static void createNewEntryLayout(JPanel tabCreate) {
		tabCreate.setLayout(new MigLayout("fill, align 50% 50%"));
		String[] choiceType = { "Breakfast", "Lunch", "Dinner", "Snack" };

		JLabel message = new JLabel("------------ Input Entry Information ------------");
		JButton btnSubmit = new JButton("Submit");
		JButton btnReset = new JButton("Reset");
		JButton btnAddIngeredient = new JButton("Add Ingredient");

		
		JLabel labelDate = new JLabel("Date (YYYY-MM-DD):");
		JLabel labelName = new JLabel("Meal Name:");
		JLabel labelType = new JLabel("Type:");
		JLabel labelIngredients = new JLabel("Ingredients ID:");
		JLabel labelQuantities = new JLabel("Quantity:");

		
		
		JTextField textDate = new JTextField();
		JTextField textName = new JTextField();
		JComboBox textType = new JComboBox(choiceType);
		JTextField textIngredients = new JTextField();
		JTextField textQuantities = new JTextField();

		BackEndMethods.setFontSize(16, labelDate, labelName, labelType, labelIngredients, labelQuantities);

		BackEndMethods.setFieldSize(200, 20, textDate, textName, textType, textIngredients, textQuantities);

		// Submit button pressed:
		btnSubmit.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					String mealName = textName.getText();
					String mealType = textType.getSelectedItem().toString();
					String date = textDate.getText();
					//

					if (mealType.equals("Breakfast")) {
						mealType = "B";
					}

					if (mealType.equals("Lunch")) {
						mealType = "L";
					}

					if (mealType.equals("Dinner")) {
						mealType = "D";
					}

					if (mealType.equals("Snack")) {
						mealType = "S";
					}

					NutrifitDatabase.foodCheck.check(date, mealType, UserSingleton.getInstance().getProfile());

					UserSingleton.getInstance().getProfile().insertUserMeal(mealName, date, mealType, ingredients);

					// Refresh the entries and update the data
					BackEndMethods.refreshEntries(ExerciseWindow.getEntriesPanel(), DietWindow.getEntriesPanel());
					ObserveDataChange.notifyObservers();

					JOptionPane.showMessageDialog(null, "Meal Added");
					resetFields(textName, textDate);
					clearIng();

				} catch (Exception SomeError) {
					JOptionPane.showMessageDialog(null,
							"Incorrect Date or Ingredient List or Meal Type!", "Error",
							JOptionPane.ERROR_MESSAGE);

				}
			}
		});

		// Reset button pressed:
		btnReset.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				int confirm = JOptionPane.showOptionDialog(null, "Reset fields?", "Confirmation",
						JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, null, null);
				if (confirm == 0) {
					textDate.setText("");
					textType.setSelectedIndex(0);
					textIngredients.setText("");
					textQuantities.setText("");
				}
				
				 clearIng();

			}
		});
		// Add Ingredient button pressed:
		btnAddIngeredient.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {

				try {
					String ing = textIngredients.getText();
					int foodID = Integer.parseInt(ing);
					String amount = textQuantities.getText();
					if (ing.equals("") || amount.equals("")) {
						throw new Exception();
					}

					IGetNutrientData data = new NutrientData(new NutrientDataMySQL());

					List<Map<String, String>> foodData = data.getFoodData(foodID);
					if (foodData.isEmpty()) {
						JOptionPane.showMessageDialog(null, "FoodID Does Not Exist", "Error",
								JOptionPane.ERROR_MESSAGE);
						foodData.clear();
					} else {

						Map<String, String> ingredient = new HashMap<>();
						ingredient.put("FoodID", ing);
						ingredient.put("Amount", amount);

						ingredients.add(ingredient);
						resetFields(textIngredients, textQuantities);
						JOptionPane.showMessageDialog(null, ingredients);
						
					}
				} catch (Exception SomeError) {
					JOptionPane.showMessageDialog(null, "Incorrect Ingredient or Quantity!", "Error",
							JOptionPane.ERROR_MESSAGE);

				}

			}
		});

		tabCreate.add(labelDate, "gaptop 30");
		tabCreate.add(textDate, "wrap");
		tabCreate.add(labelName);
		tabCreate.add(textName, "wrap");
		tabCreate.add(labelType);
		tabCreate.add(textType, "wrap");
		tabCreate.add(labelIngredients);
		tabCreate.add(textIngredients, "wrap");
		tabCreate.add(labelQuantities);
		tabCreate.add(textQuantities, "wrap");
		tabCreate.add(btnAddIngeredient, "wrap push");

		tabCreate.add(message, "grow, dock north");
		tabCreate.add(btnReset, "grow");
		tabCreate.add(btnSubmit, "grow");
	}

	private static void resetFields(JTextField textIngredients, JTextField textQuantities) {
		textIngredients.setText("");
		textQuantities.setText("");
		
	}

	public static JPanel getEntriesPanel() {
		return tabEntries;
	}
	
	public static void clearIng() {
		ingredients.clear();
	}


}
