package UI;

import NutrifitDatabase.CalculationsUtilities;
import NutrifitDatabase.IManageUserData;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Listens for observer and makes updates in Exercise Window
 */
public class ExerciseWindowListener implements Observer{
    public ExerciseWindowListener(){
        super();
        ObserveDataChange.attach(this);
    }

    //Updates the entries tab
    @Override
    public void update(){
        JPanel panel = ExerciseWindow.getEntriesPanel();
        IManageUserData user = UserSingleton.getInstance().getProfile();
        int dataLength = user.getUserExercises().size();

        //For each exercise log in database, create an associated JButton on the entries window
        for(int i = 0; i < dataLength; i++){
            panel.add(createEntry(i), "dock north");
        }
    }

    //Entries contain all data outlined in use case document + delete button
    private JButton createEntry(int i){
        IManageUserData user = UserSingleton.getInstance().getProfile();
        JButton entry = new JButton();
        JButton delete = createDeleteBtn(i);

        //Set entry text
        double caloriesBurnt = CalculationsUtilities.calculateCaloriesBurnt(
                user.getUserExercises().get(i).get("Intensity"),
                Double.valueOf(user.getUserExercises().get(i).get("Duration")),
                Double.valueOf(user.getProfileData().get("Weight")));
        int intCaloriesBurnt = (int)caloriesBurnt;

        String id = "[Entry ID:" + user.getUserExercises().get(i).get("ExerciseID");
        String date = "     Date: " + user.getUserExercises().get(i).get("DateTime") + "]";
        String duration = "  —   Duration: " + user.getUserExercises().get(i).get("Duration");
        String type = "     Type: " + user.getUserExercises().get(i).get("Type");
        String intensity = "    Intensity: " + user.getUserExercises().get(i).get("Intensity");
        String calBurn = "              Calories Burnt: " + intCaloriesBurnt;

        entry.setText(id + date + duration + type + intensity + calBurn);
        entry.setPreferredSize(new Dimension(100,100));

        entry.add(delete);

        return entry;
    }

    //Creates delete button on the entry button
    private JButton createDeleteBtn(int i) {
        IManageUserData user = UserSingleton.getInstance().getProfile();
        JButton delete = new JButton("X");
        delete.setForeground(Color.white);
        delete.setBackground(new Color(252, 80, 68));
        delete.addActionListener( new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                int confirm = JOptionPane.showOptionDialog(
                        null, "Are you sure you wish to delete this entry?",
                        "Delete Confirmation", JOptionPane.YES_NO_OPTION,
                        JOptionPane.QUESTION_MESSAGE, null, null, null);
                if (confirm == 0) {
                    //Delete functionality here
                    user.deleteUserExercise(
                            Integer.parseInt(user.getUserExercises().get(i).get("ExerciseID")));

                    //Refresh the entries and update the data
                    BackEndMethods.refreshEntries(ExerciseWindow.getEntriesPanel(), DietWindow.getEntriesPanel());
                    ObserveDataChange.notifyObservers();
                }
            }
        });

        return delete;
    }
}
