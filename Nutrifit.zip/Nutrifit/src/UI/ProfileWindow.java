package UI;

import net.miginfocom.swing.MigLayout;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;

/**
 * ProfileWindow contains "Profile Information" tab. Delete profile & change profile buttons &
 * functionality also reside here.
 */
public class ProfileWindow {

    private static JLabel userId;
    private static JLabel email;
    private static JLabel username;
    private static JLabel name;
    private static JLabel sex;
    private static JLabel birthdate;
    private static JLabel height;
    private static JLabel weight;

    private ProfileWindow(){
        initialize();
    }

    //Initialize JSwing Elements (called once)
    public static JTabbedPane initialize() {
        new ProfileWindowListener();

        userId= new JLabel();
        email = new JLabel();
        username = new JLabel();
        name = new JLabel();
        sex = new JLabel();
        birthdate = new JLabel();
        height = new JLabel();
        weight = new JLabel();

        JTabbedPane windowProfile = new JTabbedPane();
        JPanel tabInfo = createInfoLayout();
        JPanel tabSettings = new JPanel();

        createLayout(windowProfile, tabInfo, tabSettings);

        return windowProfile;
    }

    private static void createLayout(JTabbedPane tabProfile, JComponent... arg) {

        tabProfile.add("Profile Information", arg[0]);
    }

    //Create layout for profile info tab
    private static JPanel createInfoLayout(){
        JPanel subTabInfo = new JPanel();
        subTabInfo.setLayout(new MigLayout("fillx"));

        JLabel labelUserId= new JLabel("UserID:");
        JLabel labelEmail = new JLabel("Email:");
        JLabel labelUsername = new JLabel("Username:");
        JLabel labelName = new JLabel("Name:");
        JLabel labelSex = new JLabel("Sex:");
        JLabel labelBirthdate = new JLabel("Birthdate:");
        JLabel labelHeight = new JLabel("Height:");
        JLabel labelWeight = new JLabel("Weight:");

        BackEndMethods.setFontSize(16, labelUserId, labelEmail, labelUsername, labelName, labelSex,
                labelBirthdate,labelHeight, labelWeight);

        JButton btnChangeProfile = new JButton("Change Profile");
        JButton btnDeleteProfile = new JButton("Delete Profile");
        addButtonFunctionality(btnChangeProfile, btnDeleteProfile);

        subTabInfo.add(labelUserId);
        subTabInfo.add(userId, "wrap");
        subTabInfo.add(labelEmail);
        subTabInfo.add(email, "wrap");
        subTabInfo.add(labelUsername);
        subTabInfo.add(username, "wrap");
        subTabInfo.add(labelName);
        subTabInfo.add(name, "wrap");
        subTabInfo.add(labelSex);
        subTabInfo.add(sex, "wrap");
        subTabInfo.add(labelBirthdate);
        subTabInfo.add(birthdate, "wrap");
        subTabInfo.add(labelHeight);
        subTabInfo.add(height, "wrap");
        subTabInfo.add(labelWeight);
        subTabInfo.add(weight, "wrap push");
        subTabInfo.add(btnDeleteProfile, "grow");
        subTabInfo.add(btnChangeProfile, "grow");

        return subTabInfo;
    }

    public static JLabel[] getLabels(){
        return new JLabel[]{userId, email, username, name, sex, birthdate, height, weight};
    }

    //Add button functionalities for "Change Profile" & "Delete Profile"
    private static void addButtonFunctionality(JButton btnChangeProfile, JButton btnDeleteProfile ){

        //Change profile button closes profile & goes back to splash screen
        btnChangeProfile.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                int confirm = JOptionPane.showOptionDialog(
                        null, "Do you wish to sign out and return to the splash screen?",
                        "Confirmation", JOptionPane.YES_NO_OPTION,
                        JOptionPane.QUESTION_MESSAGE, null, null, null);
                if (confirm == 0) {
                    SplashScreen.showScreen("splashScreen");
                    UserSingleton.getInstance().closeProfile();
                }
            }
        });

        //Delete profile button deletes profile, closes profile & goes back to splash screen
        btnDeleteProfile.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                int confirm = JOptionPane.showOptionDialog(
                        null, "Do you wish to delete this profile return to the splash screen?",
                        "Confirmation", JOptionPane.YES_NO_OPTION,
                        JOptionPane.QUESTION_MESSAGE, null, null, null);
                if (confirm == 0) {
                    deleteProfile(username.getText());
                    SplashCreateProfile.updateSplashScreen();
                    SplashScreen.showScreen("splashScreen");
                    UserSingleton.getInstance().closeProfile();
                }
            }
        });
    }

    private static void deleteProfile(String userToDelete){
        try {
            File file = new File(SplashCreateProfile.class.getResource(
                    "/resources/usernames.txt").toURI());
            File temp = File.createTempFile("file1", ".txt", file.getParentFile());
            String charset = "UTF-8";

            // This is where the parameter goes to
            String delete = userToDelete;
            // ^^^^^
            BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file), charset));
            PrintWriter writer = new PrintWriter(new OutputStreamWriter(new FileOutputStream(temp), charset));
            for (String line; (line = reader.readLine()) != null;) {
                line = line.replaceAll("^"+delete+"$", "");
                writer.println(line);
            }
            reader.close();
            writer.close();

            file.delete();
            temp.renameTo(file);
        }
        catch (Exception e) {
            //Deletion error message here
            JOptionPane.showMessageDialog(null,
                    "There was an error with deleting this profile!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

}
