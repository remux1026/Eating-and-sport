package UI;

/**
 * Observer design pattern interface
 */
public interface Observer {
    void update();
}
