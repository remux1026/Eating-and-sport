package UI;

import javax.swing.*;
import java.awt.*;

/**
 * Contains miscellaneous methods for UI elements. Utilized in multiple different windows.
 */
public class BackEndMethods {

    public static void setFontSize(Integer size, JComponent... arg){
        for(int i = 0; i < arg.length; i++) {
            arg[i].setFont(new Font("Arial", Font.PLAIN, size));
        }
    }

    public static void setFieldSize(Integer width, Integer height, JComponent... arg){
        for(int i = 0; i < arg.length; i++) {
            arg[i].setPreferredSize(new Dimension(width,height));
        }
    }

    public static void refreshEntries(JPanel exerciseTabs, JPanel dietTabs){
        exerciseTabs.removeAll();
        exerciseTabs.revalidate();
        exerciseTabs.repaint();

        dietTabs.removeAll();
        dietTabs.revalidate();
        dietTabs.repaint();
    }

}
