package UI;

import NutrifitDatabase.VisualizationDemo;
import NutrifitDatabase.visualizeNutrientInPeriod;
import net.miginfocom.swing.MigLayout;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Contains use case 4 (Exercise Visualization) and use case 5 (Nutrient Visualization)
 * tabs and functionality.
 */
public class VisualizeWindow {

    private static JPanel visExercise;
    private static JPanel visNutrient;

    private VisualizeWindow(){
        initialize();
    }

    public static JTabbedPane initialize() {
        new VisualizeWindowListener();

        JTabbedPane windowVisualize = new JTabbedPane();
        visExercise = new JPanel();
        visNutrient = new JPanel();
        visExercise.setLayout(new MigLayout("fillx, align 50% 50%"));
        visNutrient.setLayout(new MigLayout("fillx, align 50% 50%"));

        createNutrientLayout();
        createExerciseLayout();
        createTabs(windowVisualize, visExercise, visNutrient);

        return windowVisualize;
    }

    //Create the two tabs found in the Visualize window
    private static void createTabs(JTabbedPane windowVisualize, JComponent... arg) {

        windowVisualize.add("Calorie Intake and Exercise Over Time", arg[0]);
        windowVisualize.add("Daily Nutrient Intake", arg[1]);
    }

    //Create layout of exercise visualizer (Use case 4)
    private static void createExerciseLayout(){

        JLabel description = new JLabel("Visualize your calory intake and my exercise over time.");
        JLabel description2 = new JLabel("Select a specific time period (start date to end date) and visualizer will plot your daily calory");
        JLabel description3 = new JLabel("intake and your total daily energy expenditure over this period.");

        JLabel fromLabel = new JLabel("From (yyyy-MM-dd): ");
        JLabel toLabel = new JLabel("To (yyyy-MM-dd): ");
        JTextField fromDate = new JTextField();
        JTextField toDate = new JTextField();

        //debug
        fromDate.setText("2023-10-15");
        toDate.setText("2023-10-28");

        JButton btnSubmit = new JButton("Submit");
        btnSubmit.addActionListener( new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                try {
                    getExerciseVisualization(fromDate.getText(), toDate.getText());
                } catch (Exception ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

        BackEndMethods.setFontSize(16, description, description2, description3,
                fromLabel, toLabel, fromDate, toDate);
        BackEndMethods.setFieldSize(200, 20, fromDate, toDate);

        visExercise.add(description, "wrap");
        visExercise.add(description2, "wrap");
        visExercise.add(description3, "wrap 50");
        visExercise.add(fromLabel);
        visExercise.add(fromDate, "wrap 20");
        visExercise.add(toLabel);
        visExercise.add(toDate, "wrap push");
        visExercise.add(btnSubmit, "grow x");
    }

    //Create layout of nutrient visualizer (Use case 5)
    private static void createNutrientLayout(){

        JLabel description = new JLabel("Visualize your average daily portions of specific nutrients taken over a time period.");
        JLabel description2 = new JLabel("Select a specific time period (start date to end date). The top 5 and top 10");
        JLabel description3 = new JLabel("nutrients wil lbe visualized.");

        JLabel fromLabel = new JLabel("From (yyyy-MM-dd): ");
        JLabel toLabel = new JLabel("To (yyyy-MM-dd): ");
        JTextField fromDate = new JTextField();
        JTextField toDate = new JTextField();
        JLabel exampleLabel = new JLabel("Example date format: 2023-09-15");

        JButton btnSubmit = new JButton("Submit");
        //Button funct
        btnSubmit.addActionListener( new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                try {
                    getBreakVisualization(fromDate.getText(), toDate.getText());

                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null,
                            "Invalid dates. Cannot load visualization.", "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        BackEndMethods.setFontSize(16, description, description2, description3,
                fromLabel, toLabel, fromDate, toDate);
        BackEndMethods.setFieldSize(200, 20, fromDate, toDate);

        visNutrient.add(description, "wrap");
        visNutrient.add(description2, "wrap");
        visNutrient.add(description3, "wrap 50");
        visNutrient.add(fromLabel);
        visNutrient.add(fromDate, "wrap 20");
        visNutrient.add(toLabel);
        visNutrient.add(toDate, "wrap 50");
        visNutrient.add(exampleLabel, "wrap push");
        visNutrient.add(btnSubmit, "grow x");

    }

    private static void getExerciseVisualization(String fromDate, String toDate) throws Exception {
        VisualizationDemo.getVisualization(UserSingleton.getInstance().getProfile(), fromDate, toDate);
    }
    
    private static void getBreakVisualization(String fromDate, String toDate) throws Exception {
        visualizeNutrientInPeriod.getNutrientGraph(UserSingleton.getInstance().getProfile(), fromDate, toDate);
    }

    public static JPanel getVisExercisePanel(){
        return visExercise;
    }
    public static JPanel getVisNutrientPanel(){
        return visNutrient;
    }
}
