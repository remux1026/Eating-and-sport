package UI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/**
 * Initialization of main JFrame component & all miscellaneous tasks
 * related to JFrame
 */
public class MainJFrame extends JFrame{
    public MainJFrame(){
        initialize();
    }
    private void initialize() {

        JFrame frame = new JFrame();

        //Set JFrame info
        frame.setTitle("Nutrifit");
        frame.setPreferredSize(new Dimension(1000, 600));
        frame.pack(); //Necessary for setPreferredSize
        frame.setLocationRelativeTo(null);
        frame.setFont(new Font("Arial", Font.PLAIN, 19));

        //On window close: ask confirmation & close profile
        frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        frame.addWindowListener(new WindowAdapter() {

            @Override
            public void windowClosing(WindowEvent e) {
                int confirm = JOptionPane.showOptionDialog(
                        null, "Are you sure you wish to close the application?",
                        "Exit Confirmation", JOptionPane.YES_NO_OPTION,
                        JOptionPane.QUESTION_MESSAGE, null, null, null);
                if (confirm == 0) {
                    //Close profile if it exists
                    if(UserSingleton.getInstance().getValidity()) {
                        UserSingleton.getInstance().closeProfile();
                    }
                    System.exit(0);
                }
            }

        });

        //If application shuts down unexpectedly
        Runtime.getRuntime().addShutdownHook(new Thread(new Runnable() {
            public void run() {
                //Close profile if it exists
                if(UserSingleton.getInstance().getValidity()) {
                    UserSingleton.getInstance().closeProfile();
                }
            }
        }));

        //Set window to Splash Screen on startup
        SplashScreen.initialize(frame);

        frame.setVisible(true); //Note: This component should be last after all GUI

    }
}
