package UI;

import javax.swing.*;
import java.awt.*;

/**
 * Listens for observer and makes updates in Assessments Window
 */
public class AssessmentsWindowListener implements Observer{
    public AssessmentsWindowListener(){
        super();
        ObserveDataChange.attach(this);
    }

    //When profile data changes, clear all JtextFields in Assessments Window
    @Override
    public void update(){

        for(Component control : AssessmentsWindow.getVisWeightLossPanel().getComponents()) {
            if (control instanceof JTextField) {
                JTextField ctrl = (JTextField) control;
                ctrl.setText("");
            }
        }
    }
}
