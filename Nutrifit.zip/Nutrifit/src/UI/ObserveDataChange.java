package UI;

import java.util.ArrayList;
import java.util.List;


/**
 * Observer design pattern implementation. Notifies to all UI windows that displays profile
 * data. Occurs whenever a button is pressed that would change the current
 * profile's data.
 */
public abstract class ObserveDataChange {

    private static List<Observer> observers = new ArrayList<>();

    public static void attach(Observer observer) {
        observers.add(observer);
    }

    public static void detach(Observer observer) {
        observers.remove(observer);
    }

    /*Notify each subscribed listener an update to profile data occurred */
    public static void notifyObservers() {
        for (Observer observer : observers)
            observer.update();
    }
}

