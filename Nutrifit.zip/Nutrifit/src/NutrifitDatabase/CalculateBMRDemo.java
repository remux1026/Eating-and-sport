package NutrifitDatabase;
public class CalculateBMRDemo {
	public static void main(String[] args) {
		IManageUserData user = new ManageUserDataMySQL();
		try {
		user.setUser("123", "123");
		
			System.out.println(user.getUserMeals());
			
		} catch(Exception e) 
			{System.out.println("error");
		}	
		user.close();
	}
}
