package NutrifitDatabase;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

/**
 * The concrete class used for retrieving the total
 * amount of calories expended over the last two weeks
 * @author Eduard Sinha
 *
 */
public class getCaloriesBurned implements IGetCalories{

	/**
	 * @param user - the user that is logged in
	 * 
	 * @return - returns total calories burned
	 *
	 */
	@Override
	public double getCalories(IManageUserData user) {
		// TODO Auto-generated method stub
		
		double totalCals = 0;
		
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");  
		LocalDateTime then = LocalDateTime.now().minusDays(14);

		double weight = Double.parseDouble(user.getProfileData().get("Weight"));
		int max = user.getUserExercises().size();
		for(int i = 1; i <= max; i++) {
			LocalDateTime cur = LocalDateTime.parse(user.getUserExercises().get(max - i).get("DateTime"), dtf);
			if(cur.isAfter(then)) {
				double calories = CalculationsUtilities.calculateCaloriesBurnt(user.getUserExercises().get(max - i).get("Intensity"), 
					Double.valueOf(user.getUserExercises().get(max - i).get("Duration")), weight);
				totalCals = totalCals + calories;
			}
		
		}

		return totalCals;
	}
	

}
