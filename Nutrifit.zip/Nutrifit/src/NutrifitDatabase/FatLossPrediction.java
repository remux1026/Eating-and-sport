package NutrifitDatabase;

import java.time.Duration;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Use Case 6, predicts the estimated amount of fat loss
 * based on recent eating and exercise patterns
 * @author Eduard Sinha
 *
 */


public class FatLossPrediction {

	/**
	 * @param user - the user that is logged in
	 * @param data - the date the user wants to know 
	 * 				how much fat will be lost by
	 * @return - returns estimated fat loss in kgs
	 * @throws Exception 
	 *
	 */
	public static double predict(IManageUserData user, String date) throws Exception {
		
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");  
		LocalDateTime now = LocalDateTime.now(); 
		LocalDateTime toDate = LocalDateTime.parse(date+" 00:00", dtf);
		Duration diff = Duration.between(now, toDate);
		if(diff.toDays() > 0) {
			
		Map<String, String> profile = user.getProfileData();
		double BMR = CalculationsUtilities.bmr(profile.get("Birthday"), profile.get("Sex"), 
				Double.valueOf(profile.get("Height")), Double.valueOf(profile.get("Weight")));
		
		//Strategy Pattern
		IGetCalories bruned = new getCaloriesBurned();
		double burn = bruned.getCalories(user);
		
		IGetCalories intake = new getCaloriesIntake();
		double eaten = intake.getCalories(user);
		
		double totalAvgCalDay = ((burn + BMR) - eaten)/14;
		
		double predictedLoss = (totalAvgCalDay * diff.toDays())/7700;
		
		return predictedLoss;
		} else {
			throw new Exception() ;
			
		}
	}
	


}
