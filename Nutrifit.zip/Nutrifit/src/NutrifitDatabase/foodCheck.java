package NutrifitDatabase;

import java.util.List;
import java.util.Map;

import NutrifitDatabase.IManageUserData;

public class foodCheck {

	public static void check(String date,String mealType, IManageUserData user) throws Exception{
		boolean exists = false;
		for(int i = 0; user.getUserMeals().size() > i ; i++) {
			if (date.equals(user.getUserMeals().get(i).get("Date"))) {
				if (mealType.equals(user.getUserMeals().get(i).get("Type")) && !mealType.equals("S")) {
					exists = true;
					break;
				}
			} 
		}
		

		
		//check for type
		if(exists) {
			throw new Exception();
		}
	}
	
}
