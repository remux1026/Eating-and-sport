package NutrifitDatabase;

/**
 * One of the concrete classes
 * that retrives CFG based on age
 * @author Eduard Sinha
 *
 */
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class getAdultsOld implements ISelectCFG{
	
	/**
	 * @param sex - the sex of the user
	 * 
	 * @return - returns a map of correlating CFG data
	 *
	 */
	@Override
	public Map<String, Integer> selectCFG(String sex) {
		// TODO Auto-generated method stub
		Map<String, Integer> result = new HashMap<String,Integer>();
		
		if(sex.equals("M")) {
			//Vegetable
			result.put("Vegetable", 7);
			//Grains
			result.put("Grains", 7);
			//Milk
			result.put("Milk", 3);
			//Meat
			result.put("Meat", 3);
		} else {
			//Vegetable
			result.put("Vegetable", 7);
			//Grains
			result.put("Grains", 6);
			//Milk
			result.put("Milk", 3);
			//Meat
			result.put("Meat", 2);
		}
		
		return result;
	}
	
}
