package NutrifitDatabase;

/**
 * One of the concrete classes
 * that sorts for grain products
 * @author Eduard Sinha
 *
 */
import java.util.Map;

public class grainCheck extends foodSorter{
	
	/**
	 * @param user - the user that is logged in
	 * @param map - the map used to store all the food data
	 * 
	 * @return - returns the next sorting class for sorting
	 *
	 */
	@Override
	public Map<String, Integer> sort(IManageUserData user, Map<String, Integer> map) {
		double amount = 0;
		IGetNutrientData data = new NutrientData(new NutrientDataMySQL());
     
		for(Map<String, String> entry : user.getUserMealIngredients()) {

			if(data.getFoodData(Integer.parseInt(entry.get("FoodID"))).get(0).get("FoodGroupName").equals("Breakfast cereals")
					|| data.getFoodData(Integer.parseInt(entry.get("FoodID"))).get(0).get("FoodGroupName").equals("Cereals, Grains and Pasta")
					|| data.getFoodData(Integer.parseInt(entry.get("FoodID"))).get(0).get("FoodGroupName").equals("Baked Products")
					|| data.getFoodData(Integer.parseInt(entry.get("FoodID"))).get(0).get("FoodGroupName").equals("Cereals, Grains and Pasta")
					|| data.getFoodData(Integer.parseInt(entry.get("FoodID"))).get(0).get("FoodGroupName").equals("Spices and Herbs")) {
				amount += Double.parseDouble(entry.get("Amount"));
			}
		}
		
		map.put("Grains", (int)(amount));
		return sortNext(user, map);
	}
}
