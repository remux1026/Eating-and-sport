package NutrifitDatabase;

import java.util.Map;

/**
 * One of the concrete classes
 * that sorts for dairy products
 * @author Eduard Sinha
 *
 */
public class dairyCheck extends foodSorter {
	
	/**
	 * @param user - the user that is logged in
	 * @param map - the map used to store all the food data
	 * 
	 * @return - returns the next sorting class for sorting
	 *
	 */
	@Override
	public Map<String, Integer> sort(IManageUserData user, Map<String, Integer> map) {
		double amount = 0;
		IGetNutrientData data = new NutrientData(new NutrientDataMySQL());
     
		for(Map<String, String> entry : user.getUserMealIngredients()) {
			if(data.getFoodData(Integer.parseInt(entry.get("FoodID"))).get(0).get("FoodGroupName").equals("Dairy and Egg Products")) {
				amount += Double.parseDouble(entry.get("Amount"));
			}
		}
		
		map.put("Milk", (int)(amount));
		return sortNext(user, map);
	}
}
