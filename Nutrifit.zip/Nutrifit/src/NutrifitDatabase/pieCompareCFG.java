package NutrifitDatabase;

/**
 * Creates a visualization of two pie charts
 * that show the comparison between the user food
 * and the CFG
 * @author Eduard Sinha
 *
 */
import java.awt.Color;
import java.text.DecimalFormat;
import java.util.Map;

import javax.swing.JFrame;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.labels.StandardPieSectionLabelGenerator;
import org.jfree.chart.plot.MultiplePiePlot;
import org.jfree.chart.plot.PiePlot;
import org.jfree.chart.util.TableOrder;
import org.jfree.data.category.DefaultCategoryDataset;


public class pieCompareCFG extends JFrame {
	

	public pieCompareCFG() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setSize(1360, 450);
	}
	
	/**
	 * @param cfg - the CFG data
	 * @param userFood - the user food data
	 * 
	 * Displays a pie chart comparing the CFG and User Diet
	 *
	 */
	public void visualize(Map<String, Integer> cfg, Map<String, Integer> userFood) {
		DefaultCategoryDataset dataset = new DefaultCategoryDataset();

		for (Map.Entry<String, Integer> entry : cfg.entrySet()) {
			dataset.addValue(entry.getValue(), entry.getKey(), "CFG");
		}

		for (Map.Entry<String, Integer> entry : userFood.entrySet()) {
			dataset.addValue(entry.getValue(), entry.getKey(), "Your Food");
		}

		JFreeChart chart = ChartFactory.createMultiplePieChart3D("Food Comparison", dataset, TableOrder.BY_COLUMN,
				true, true, false);

		MultiplePiePlot plot = (MultiplePiePlot) chart.getPlot();

		ChartPanel panel = new ChartPanel(chart);
		JFreeChart subchart = plot.getPieChart();
		PiePlot p = (PiePlot) subchart.getPlot();
		p.setLabelGenerator(
				new StandardPieSectionLabelGenerator("{0} : ({2})", new DecimalFormat("0"), new DecimalFormat("0%")));
		p.setSectionPaint("Vegetable", new Color(157, 193, 131));
		p.setSectionPaint("Grains", new Color(230, 223, 0));
		p.setSectionPaint("Milk", new Color(135, 206, 250));
		p.setSectionPaint("Meat", new Color(254, 57, 57));
		p.setSectionPaint("Unknown", Color.BLACK);
		setContentPane(panel);
		setVisible(true);
	}

}
