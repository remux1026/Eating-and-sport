package NutrifitDatabase;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Map;

public class DatabaseUtilities {
	
	public static List<Map<String, String>> allProfiles(){
		Connection con = null;
		Statement st = null;
		ResultSet res = null;
		
		try {
			con = JDBCUtilities.getDataSource().getConnection();
			String query = "SELECT * FROM UserLogging.`USER PROFILE`";
			st = con.createStatement();
			
			res = st.executeQuery(query);
			
			List<Map<String, String>> ret = JDBCUtilities.extractResult(res);
			JDBCUtilities.close(con, st, res);
			return ret;
			
			
		} catch (SQLException e) {
			JDBCUtilities.close(con, st, res);
			return null;
		}
	}
	
	public static void free(int userID) {
		Connection con = null;
		Statement st = null;
		
		try {
			con = JDBCUtilities.getDataSource().getConnection();
			String query = 
					String.format("update UserLogging.`USER PROFILE` set Locked = 0 where UserID = %d", userID);
			st = con.createStatement();
			st.executeUpdate(query);
			
			JDBCUtilities.close(con, st, null);
			
		} catch (SQLException e) {
			JDBCUtilities.close(con, st, null);
		}
	}
}