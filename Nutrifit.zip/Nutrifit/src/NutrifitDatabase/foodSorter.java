package NutrifitDatabase;

/**
 * The abstract class using the Chain of
 * Responsibility to sort the meal ingredients
 * to the CFG parameters 
 * @author Eduard Sinha
 *
 */
import java.util.Map;

public abstract class foodSorter {

		private foodSorter next;
		
		public foodSorter setNextfoodSorter(foodSorter next) {
			this.next = next;
			return next;
		}
		
		public abstract Map<String, Integer> sort(IManageUserData user, Map<String, Integer> map);
		
		protected Map<String, Integer> sortNext(IManageUserData user, Map<String, Integer> map){
			if (this.next == null) {
				return map;
			}
			return next.sort(user, map);
		}


			
		
}
