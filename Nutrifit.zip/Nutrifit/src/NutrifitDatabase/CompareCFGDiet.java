package NutrifitDatabase;

import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * The concrete class used for retrieving the total
 * amount of calories eaten over the last two weeks
 * @author Eduard Sinha
 *
 */

public class CompareCFGDiet {
	
	/**
	 * @param user - the user that is logged in
	 * 
	 * Calls pieCompare
	 * @throws Exception 
	 *
	 */
	public static void compareCFGVisual(IManageUserData user)  {
		LocalDate d1 = LocalDate.parse(user.getProfileData().get("Birthday"), DateTimeFormatter.ISO_LOCAL_DATE);
    	LocalDate d2 = LocalDate.now();
    	Duration diff = Duration.between(d1.atStartOfDay(), d2.atStartOfDay());
    	long age = diff.toDays() / 365;
    	Map<String, Integer> map = new HashMap<String, Integer>();
		
		
		ISelectCFG cfg = null;
		
		if(age > 51) {cfg = new getAdultsOld();}
		else if(age > 19) {cfg = new getAdultsYoung();}
		else if(age > 14) {cfg = new getTeens();}
		//else {throw new Exception("fd");};

		
		foodSorter vegCheck = new vegCheck();
		foodSorter grainCheck = new grainCheck();
		foodSorter dairyCheck = new dairyCheck();
		foodSorter meatCheck = new meatCheck();
		foodSorter otherCheck = new otherCheck();
		vegCheck.setNextfoodSorter(grainCheck);
		grainCheck.setNextfoodSorter(dairyCheck);
		dairyCheck.setNextfoodSorter(meatCheck);
		meatCheck.setNextfoodSorter(otherCheck);
		vegCheck.sort(user, map);
			
		
		Map<String, Integer> cfgMap = cfg.selectCFG(user.getProfileData().get("Sex"));
		Map<String, Integer> userMap = map;

		pieCompareCFG pie = new pieCompareCFG();
		pie.visualize(cfgMap, userMap);
		
	}
	

}