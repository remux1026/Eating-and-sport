package NutrifitDatabase;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;

public class MealLoggingDemo {
	public static void main(String[] args) {
		IManageUserData user = new ManageUserDataMySQL();
		try {
		user.setUser("123", "123");
		
		List<Map<String, String>> ingredients = new ArrayList<>();
		
		Map<String, String> ingredient1 = new HashMap<>();
		ingredient1.put("FoodID", "12");
		ingredient1.put("Amount", "23");
		
		Map<String, String> ingredient2 = new HashMap<>();
		ingredient2.put("FoodID", "23");
		ingredient2.put("Amount", "12");
		
		ingredients.add(ingredient1);
		ingredients.add(ingredient2);
		
		user.insertUserMeal("restr", "2023-11-20", "B", ingredients);
		
		System.out.println(ingredients);
		} catch (Exception e) {
			
		}
		user.close();
		
	}
}
