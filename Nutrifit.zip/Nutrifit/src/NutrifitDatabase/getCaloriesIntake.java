package NutrifitDatabase;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
/**
 * The concrete class used for retrieving the total
 * amount of calories eaten over the last two weeks
 * @author Eduard Sinha
 *
 */
public class getCaloriesIntake implements IGetCalories{
	
	/**
	 * @param user - the user that is logged in
	 * 
	 * @return - returns total calories eaten
	 *
	 */
	@Override
	public double getCalories(IManageUserData user) {
		// TODO Auto-generated method stub
		double totalCals = 0;
		
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");  
		LocalDateTime then = LocalDateTime.now().minusDays(14);
		int max = user.getUserMeals().size();
		
		for(int i = 1; i <= max; i++) {
		
			LocalDateTime cur = LocalDateTime.parse(user.getUserMeals().get(max - i).get("Date")+" 00:00:00", dtf);
			if(cur.isAfter(then)) {
				
				String randomMealID = user.getUserMeals().get(max - i).get("MealID");
				List<Map<String, String>> mealIngredients = user.getUserMealIngredients().stream().
						filter(tuple -> tuple.get("MealID").equals(randomMealID)).collect(Collectors.toList());
				double calories = CalculationsUtilities.getMealCalories(mealIngredients);
				totalCals = totalCals + calories;
				
			}
		
		}

		return totalCals;
	}
	
	
}
