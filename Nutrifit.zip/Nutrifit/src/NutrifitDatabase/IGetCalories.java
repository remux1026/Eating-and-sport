package NutrifitDatabase;

/**
 * Interface used for the strategy pattern
 * to calculate the diffrent calorie amounts
 * expended and intake
 * @author Eduard Sinha
 *
 */

public interface IGetCalories {
	
	public double getCalories(IManageUserData user);
}
