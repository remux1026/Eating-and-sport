package NutrifitDatabase;

/**
 * One of the concrete classes
 * that sorts for meat products
 * @author Eduard Sinha
 *
 */
import java.util.HashMap;
import java.util.Map;

public class meatCheck extends foodSorter{
	
	/**
	 * @param user - the user that is logged in
	 * @param map - the map used to store all the food data
	 * 
	 * @return - returns the next sorting class for sorting
	 *
	 */
	@Override
	public Map<String, Integer> sort(IManageUserData user, Map<String, Integer> map) {
		double amount = 0;
		IGetNutrientData data = new NutrientData(new NutrientDataMySQL());
		
		for(Map<String, String> entry : user.getUserMealIngredients()) {
			if(data.getFoodData(Integer.parseInt(entry.get("FoodID"))).get(0).get("FoodGroupName").equals("Poultry Products")
					|| data.getFoodData(Integer.parseInt(entry.get("FoodID"))).get(0).get("FoodGroupName").equals("Sausages and Luncheon meats")
					|| data.getFoodData(Integer.parseInt(entry.get("FoodID"))).get(0).get("FoodGroupName").equals("Pork Products")
					|| data.getFoodData(Integer.parseInt(entry.get("FoodID"))).get(0).get("FoodGroupName").equals("Nuts and Seeds")
					|| data.getFoodData(Integer.parseInt(entry.get("FoodID"))).get(0).get("FoodGroupName").equals("Beef Products")
					|| data.getFoodData(Integer.parseInt(entry.get("FoodID"))).get(0).get("FoodGroupName").equals("Finfish and Shellfish Products")
					|| data.getFoodData(Integer.parseInt(entry.get("FoodID"))).get(0).get("FoodGroupName").equals("Legumes and Legume Products")
					|| data.getFoodData(Integer.parseInt(entry.get("FoodID"))).get(0).get("FoodGroupName").equals("Lamb, Veal and Game")) {
				amount += Double.parseDouble(entry.get("Amount"));
				
			}
		}
		
		map.put("Meat", (int)(amount));
		return sortNext(user, map);
	}
}
