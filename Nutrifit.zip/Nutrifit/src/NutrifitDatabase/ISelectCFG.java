package NutrifitDatabase;
/**
 * The interface used for the CFG
 * food data based on age
 * @author Eduard Sinha
 *
 */
import java.util.Map;

public interface ISelectCFG {
	
	public Map<String, Integer> selectCFG(String sex);
	
}
