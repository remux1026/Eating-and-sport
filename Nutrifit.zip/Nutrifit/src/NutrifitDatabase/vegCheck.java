package NutrifitDatabase;

/**
 * One of the concrete classes
 * that sorts for vegetable products
 * @author Eduard Sinha
 *
 */
import java.util.Map;

public class vegCheck extends foodSorter{
	
	
	/**
	 * @param user - the user that is logged in
	 * @param map - the map used to store all the food data
	 * 
	 * @return - returns the next sorting class for sorting
	 *
	 */
	@Override
	public Map<String, Integer> sort(IManageUserData user, Map<String, Integer> map) {
		double amount = 0;
		IGetNutrientData data = new NutrientData(new NutrientDataMySQL());
		for(Map<String, String> entry : user.getUserMealIngredients()) {
			if(data.getFoodData(Integer.parseInt(entry.get("FoodID"))).get(0).get("FoodGroupName").equals("Vegetables and Vegetable Products")
					|| data.getFoodData(Integer.parseInt(entry.get("FoodID"))).get(0).get("FoodGroupName").equals("Fruits and fruit juices")) {
				amount += Double.parseDouble(entry.get("Amount"));
				
			}
		}
		
		map.put("Vegetable", (int)(amount));
		return sortNext(user, map);
	}

}
