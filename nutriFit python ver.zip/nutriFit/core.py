import core
import eating
import food
import schedule
import Searcher
import sport
import user
import sys        # 系统相关操作
import os         # 操作系统交互
import shutil     # 文件复制、移动等操作
import pathlib    # 处理文件路径
import glob       # 处理文件匹配（如获取所有 .txt 文件）
import logging    # 记录日志
import argparse   # 命令行参数解析
import configparser  # 解析配置文件 (.ini)
import platform   # 获取操作系统信息
import ui
import database
class core:
    def __init__(self,id,user,database,ui):
        self.id=id
        self.user=user
        self.database=database
        self.ui=ui
    def set_user(self,user_id,name,age,weight,height,schedule=[],plan=[],menu=[]):
        new_user=user(user_id,name,age,weight,height,schedule,plan,menu)
        self.user=new_user
        return new_user
    def set_database(self,new_database):
        self.database=new_database
        return new_database
    def start(self):
        self.ui.print_welcome_page()
        new_user=user(-1,"default",0,0,0,[],[],[])
        self.database=new_database
        self.user=new_user
        self.ui.display_main_menu()
        self.ui.get_user_choice()
