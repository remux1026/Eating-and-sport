import core
import eating
import event
import food
import Searcher
import sport
import user
import sys        # 系统相关操作
import os         # 操作系统交互
import shutil     # 文件复制、移动等操作
import pathlib    # 处理文件路径
import glob       # 处理文件匹配（如获取所有 .txt 文件）
import logging    # 记录日志
import argparse   # 命令行参数解析
import configparser  # 解析配置文件 (.ini)
import platform   # 获取操作系统信息
class schedule:
    def __init__(self,start_date,end_date,event_list=[]):
        self.start_date=start_date
        self.end_date=end_date
        if event_list!=[]:
            #if not empty,then copy the list
            self.event_list=event_list
        else:
            #if empty then create empty list
            self.event_list=[]
    def add_event_simple(self,event):
        self.event_list.append(event)
    def add_event_in_date_oreder(self,date,event):
        index=date-self.start_date
        if self.event_list==[]:
            for i in range(index):
                self.event_list.append(None)
            self.event_list.append(event)
        elif index>len(self.event_list):
            for i in range(index-len(self.event_list)):
                self.event_list.append(None)
            self.event_list.append(event)
        else:
            self.event_list.append(event)
    def get_date_fat_change(self,date):
        fat_change=0
        for event in self.event_list:
            if isinstance(event,sport):
                fat_change-=event.fat_lost
            if isinstance(event,eating):
                fat_change-=event.fat_gain
        return fat_change
    def get_date_weight_change(self,date):
        energy_change=0
        for event in self.event_list:
            if isinstance(event,sport):
                if event.date==date:
                    energy_change-=event.energy_lost
            if isinstance(event,eating):
                if event.date==date:
                    energy_change-=event.energy_gain
        weight_change=energy_change/9
        return weight_change

    def get_date_fat_change(self,date):
        fat_change=0
        for event in self.event_list:
            if isinstance(event,sport):
                if event.date==date:
                    fat_change-=event.fat_lost
            if isinstance(event,eating):
                if event.date==date:
                    fat_change-=event.fat_gain
        return fat_change
    def get_date_vitaminA_change(self,date):
        vitaminA_change=0
        for event in self.event_list:
            if isinstance(event,sport):
                if event.date==date:
                    vitaminA_change-=event.vitaminA_lost
            if isinstance(event,eating):
                if event.date==date:
                    vitaminA_change-=event.vitaminA_gain
        return vitaminA_change
    def get_date_vitaminB_change(self,date):
        vitaminB_change=0
        for event in self.event_list:
            if isinstance(event,sport):
                if event.date==date:
                    vitaminB_change-=event.vitaminB_lost
            if isinstance(event,eating):
                if event.date==date:
                    vitaminB_change-=event.vitaminB_gain
        return vitaminB_change
    def get_date_vitaminC_change(self,date):
        vitaminC_change=0
        for event in self.event_list:
            if isinstance(event,sport):
                if event.date==date:
                    vitaminC_change-=event.vitaminC_lost
            if isinstance(event,eating):
                if event.date==date:
                    vitaminC_change-=event.vitaminC_gain
        return vitaminC_change
    def get_date_energy_change(self,date):
        energy_change=0
        for event in self.event_list:
            if isinstance(event,sport):
                if event.date==date:
                    energy_change-=event.energy_lost
            if isinstance(event,eating):
                if event.date==date:
                    energy_change-=event.energy_gain
        return energy_change
