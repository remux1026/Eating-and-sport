import core
import event
import food
import schedule
import Searcher
import sport
import user
import sys        # 系统相关操作
import os         # 操作系统交互
import shutil     # 文件复制、移动等操作
import pathlib    # 处理文件路径
import glob       # 处理文件匹配（如获取所有 .txt 文件）
import logging    # 记录日志
import argparse   # 命令行参数解析
import configparser  # 解析配置文件 (.ini)
import platform   # 获取操作系统信息
class eating:
    #man event
    def __init__(self,food,weight):
        self.food_name=food_name
        self.energy_gain=food.energy*weight
        self.fat_gain=food.fat*weight
        self.protein_gain=food.protein*weight
        self.vitaminA_gain=self.vitaminA_gain*weight
        self.vitaminB_gain=self.vitaminB_gain*weight
        self.vitaminC_gain=self.vitaminC_gain*weight
