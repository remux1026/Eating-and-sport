import core
import eating
import food
import schedule
import Searcher
import sport
import user
import sys        # 系统相关操作
import os         # 操作系统交互
import shutil     # 文件复制、移动等操作
import pathlib    # 处理文件路径
import glob       # 处理文件匹配（如获取所有 .txt 文件）
import logging    # 记录日志
import argparse   # 命令行参数解析
import configparser  # 解析配置文件 (.ini)
import platform   # 获取操作系统信息

class event:
    def __init__(self,type,date):
        self.type=type
        self.date=date
