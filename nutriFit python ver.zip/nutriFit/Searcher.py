import core
import eating
import event
import food
import schedule
import sport
import user
import sys        # 系统相关操作
import os         # 操作系统交互
import shutil     # 文件复制、移动等操作
import pathlib    # 处理文件路径
import glob       # 处理文件匹配（如获取所有 .txt 文件）
import logging    # 记录日志
import argparse   # 命令行参数解析
import configparser  # 解析配置文件 (.ini)
import platform   # 获取操作系统信息

class Searcher:
    #food=[name,energy,fat,protein,vitaminA,vitaminB,vitaminC]
    #search food by food name
    def fname_search(self,arr,tar):
        length=len(arr)
        index=-1
        while(index<length):
            index+=1
            temp=arr[index][0]
            if(temp==tar):
                return index
    def fenergy_search(arr,tar):
        for index in range(len(arr)):
            energy=arr[index][0]
            if energy==tar:
                return index
    def ffat_search(arr,tar):
        for index in range(len(arr)):
            fat=arr[index][1]
            if fat==tar:
                return index
    def fprotein_search(arr,tar):
        index=0
        while(index<len(arr)):
            protein=arr[index][3]
            if protein==tar:
                return index#可能会无法测试
            index+=1
        return -1
    def fvitaminA_search(arr,tar):
        index=0
        while(index<len(arr)):
            protein=arr[index][4]
            if protein==tar:
                return index#可能会无法测试
            index+=1
        return -1
    def fvitaminB_search(arr,tar):
        index=0
        while(index<len(arr)):
            protein=arr[index][5]
            if protein==tar:
                return index#可能会无法测试
            index+=1
        return -1
    def fvitaminC_search(arr,tar):
        index=0
        while(index<len(arr)):
            protein=arr[index][6]
            if protein==tar:
                return index#可能会无法测试
            index+=1
        return -1
    #abonded methods,jut keep it here in case needed
    def linear_search(self,arr,tar):
        length=len(arr)
        index=-1
        while(index<length):
            index+=1
            temp=arr[index]
            if(temp==tar):
                return index
    def binary_search_food_by_energy(foodlist, target_energy):
        left, right= 0, len(foodlist) - 1
        while left <= right:
            mid=(left+right)//2
            if foodlist[mid][1]==target_energy:
                return foodlist[mid]
            elif foodlist[mid][1]<target_energy:
                left=mid+1
            else:
                right=mid-1
        return None
    def binary_search_food_by_protein(foodlist, target_protein):
        left,right=0,len(foodlist) - 1
        while left<=right:
            mid=(left+right)//2
            if foodlist[mid][3]==target_protein:
                return foodlist[mid]
            elif foodlist[mid][3]<target_protein:
                left=mid+1
            else:
                right=mid-1
        return None
    def binary_search_food_by_vitaminA(foodlist, target_vitaminA):
        left, right = 0, len(foodlist) - 1
        while left <= right:
            mid = (left + right) // 2
            if foodlist[mid][4] == target_vitaminA:
                return foodlist[mid]
            elif foodlist[mid][4] < target_vitaminA:
                left = mid + 1
            else:
                right = mid - 1
        return None
    def binary_search_food_by_vitaminB(foodlist, target_vitaminA):
        left, right = 0, len(foodlist) - 1
        while left <= right:
            mid = (left + right) // 2
            if foodlist[mid][5] == target_vitaminA:
                return foodlist[mid]
            elif foodlist[mid][5] < target_vitaminA:
                left = mid + 1
            else:
                right = mid - 1
        return None
    def binary_search_food_by_vitaminC(foodlist, target_vitaminA):
        left, right = 0, len(foodlist) - 1
        while left <= right:
            mid = (left + right) // 2
            if foodlist[mid][6] == target_vitaminA:
                return foodlist[mid]
            elif foodlist[mid][6] < target_vitaminA:
                left = mid + 1
            else:
                right = mid - 1
        return None
