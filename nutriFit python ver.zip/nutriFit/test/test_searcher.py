import unittest


import sys
sys.path.append("..")

# 现在可以导入searcher模块
from Searcher import Searcher
from sport import sport

class TestSearcher(unittest.TestCase):
        def setUp(self):
                # Create an instance of Calculator before each test
                self.searcher = Searcher()

        def test_linearSearch(self):
            self.assertEqual(self.searcher.linear_search([0,1,2,3,4,5,6],6), 6)
        # def test_fname_search(self):
        #     foods=[
        #         ["iceream",1,2,3,4,5,6],
        #         ["fries",1,2,3,4,5,6],
        #         ["coke",1,2,3,4,5,6],
        #     ]
        #     tar="coke"
        #     self.assertEqual(self.searcher.fname_search(foods,tar), 2)
if __name__ == '__main__':
    unittest.main()
